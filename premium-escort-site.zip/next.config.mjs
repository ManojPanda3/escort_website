/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    domains: ['isogrkikdwmiagdbwctx.supabase.co'],
  },
}

export default nextConfig

