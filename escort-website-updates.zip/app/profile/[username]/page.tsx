import { createServerComponentClient } from '@supabase/auth-helpers-nextjs'
import { cookies } from 'next/headers'
import { notFound } from 'next/navigation'
import { ProfileHeader } from '../profile-header'
import { ProfileTabs } from '../profile-tabs'

export default async function ProfilePage({
  params
}: {
  params: { username: string }
}) {
  const supabase = createServerComponentClient({ cookies })
  
  const { data: profile } = await supabase
    .from('users')
    .select('*')
    .eq('username', params.username)
    .single()

  if (!profile) {
    notFound()
  }

  const { data: pictures } = await supabase
    .from('pictures')
    .select('*')
    .eq('owner', profile.id)
    .order('created_at', { ascending: false })

  const { data: services } = await supabase
    .from('services')
    .select('*')
    .eq('owner', profile.id)

  const { data: rates } = await supabase
    .from('rates')
    .select('*')
    .eq('owner', profile.id)

  const { data: testimonials } = await supabase
    .from('testimonials')
    .select('*, users!testimonials_owner_fkey(*)')
    .eq('to', profile.id)

  const { data: { session } } = await supabase.auth.getSession()
  const isOwnProfile = session?.user?.id === profile.id

  return (
    <main className="container mx-auto px-4 py-8">
      <ProfileHeader profile={profile} isOwnProfile={isOwnProfile} />
      <ProfileTabs 
        pictures={pictures || []}
        services={services || []}
        rates={rates || []}
        testimonials={testimonials || []}
        isOwnProfile={isOwnProfile}
      />
    </main>
  )
}

