'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import Image from 'next/image'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { AlertCircle, Loader2 } from 'lucide-react'
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert'

interface EditProfileFormProps {
  profile: any
}

export function EditProfileForm({ profile }: EditProfileFormProps) {
  const router = useRouter()
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [formData, setFormData] = useState({
    name: profile?.name || '',
    about: profile?.about || '',
    location: profile?.location || '',
    phone_number: profile?.phone_number || '',
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError('')

    const form = new FormData()
    Object.entries(formData).forEach(([key, value]) => {
      form.append(key, value as string)
    })

    const response = await fetch('/api/profile/update', {
      method: 'POST',
      body: form,
    })

    const data = await response.json()

    if (!response.ok) {
      setError(data.error)
    } else {
      router.refresh()
    }

    setLoading(false)
  }

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>, type: 'profile' | 'cover') => {
    const file = e.target.files?.[0]
    if (!file) return

    setLoading(true)
    setError('')

    const form = new FormData()
    form.append(type === 'profile' ? 'profile_picture' : 'cover_image', file)

    const response = await fetch('/api/profile/update', {
      method: 'POST',
      body: form,
    })

    const data = await response.json()

    if (!response.ok) {
      setError(data.error)
    } else {
      router.refresh()
    }

    setLoading(false)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Edit Profile</CardTitle>
      </CardHeader>
      <CardContent>
        {error && (
          <Alert variant="destructive" className="mb-4">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Error</AlertTitle>
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label>Cover Image</Label>
            <div className="relative h-48 w-full overflow-hidden rounded-lg">
              <Image
                src={profile.cover_image || '/placeholder.svg?height=400&width=800'}
                alt="Cover"
                fill
                className="object-cover"
              />
            </div>
            <Input
              type="file"
              accept="image/*"
              onChange={(e) => handleImageUpload(e, 'cover')}
              disabled={loading}
            />
          </div>

          <div className="space-y-2">
            <Label>Profile Picture</Label>
            <div className="flex items-center gap-4">
              <div className="h-20 w-20 relative rounded-full overflow-hidden">
                <Image
                  src={profile.profile_picture || '/placeholder.svg?height=200&width=200'}
                  alt={profile.name}
                  fill
                  className="object-cover"
                />
              </div>
              <Input
                type="file"
                accept="image/*"
                onChange={(e) => handleImageUpload(e, 'profile')}
                disabled={loading}
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="name">Name</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                disabled={loading}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="location">Location</Label>
              <Input
                id="location"
                value={formData.location}
                onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                disabled={loading}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="phone">Phone Number</Label>
              <Input
                id="phone"
                value={formData.phone_number}
                onChange={(e) => setFormData({ ...formData, phone_number: e.target.value })}
                disabled={loading}
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="about">About</Label>
            <Textarea
              id="about"
              value={formData.about}
              onChange={(e) => setFormData({ ...formData, about: e.target.value })}
              disabled={loading}
              className="min-h-[100px]"
            />
          </div>

          <Button type="submit" disabled={loading}>
            {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Save Changes
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}

