import { createRouteHandlerClient } from '@supabase/auth-helpers-nextjs'
import { cookies } from 'next/headers'
import { NextRequest, NextResponse } from 'next/server'

export async function POST(request: NextRequest) {
  const supabase = createRouteHandlerClient({ cookies })
  const { data: { session } } = await supabase.auth.getSession()

  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const formData = await request.formData()
  const coverImage = formData.get('cover_image') as File
  const updates = Object.fromEntries(formData.entries())
  delete updates.cover_image

  // Handle cover image upload if provided
  if (coverImage) {
    const fileExt = coverImage.name.split('.').pop()
    const fileName = `${session.user.id}_cover_${Date.now()}.${fileExt}`
    const { error: uploadError } = await supabase.storage
      .from('profile_covers')
      .upload(fileName, coverImage)

    if (uploadError) {
      return NextResponse.json(
        { error: 'Error uploading cover image' },
        { status: 400 }
      )
    }

    updates.cover_image = fileName
  }

  const { error } = await supabase
    .from('users')
    .update(updates)
    .eq('id', session.user.id)

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 400 })
  }

  return NextResponse.json({ message: 'Profile updated successfully' })
}

